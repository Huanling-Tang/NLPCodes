import torch.nn as nn
import pywt
import numpy as np
import torch.nn.functional as F
from torch.autograd import Function
import torch


def sfb1d(lo, hi, g0, g1, mode='zero', dim=-1):
    """ 1D synthesis filter bank of an image tensor
    """
    C = lo.shape[1]
    d = dim % 4
    if not isinstance(g0, torch.Tensor):
        g0 = torch.tensor(np.copy(np.array(g0).ravel()),
                          dtype=torch.float, device=lo.device)
    if not isinstance(g1, torch.Tensor):
        g1 = torch.tensor(np.copy(np.array(g1).ravel()),
                          dtype=torch.float, device=lo.device)
    L = g0.numel()
    shape = [1,1,1,1]
    shape[d] = L
    # If g aren't in the right shape, make them so
    if g0.shape != tuple(shape):
        g0 = g0.reshape(*shape)
    if g1.shape != tuple(shape):
        g1 = g1.reshape(*shape)
    s = (2, 1) if d == 2 else (1,2)
    g0 = torch.cat([g0]*C,dim=0)
    g1 = torch.cat([g1]*C,dim=0)

    if mode == 'zero' :
        pad = (L-2, 0) if d == 2 else (0, L-2)
        y = F.conv_transpose2d(lo, g0, stride=s, padding=pad, groups=C) + \
            F.conv_transpose2d(hi, g1, stride=s, padding=pad, groups=C)
    else:
        raise ValueError("Unkown pad type: {}".format(mode))

    return y

def get_lohi(x, h0, h1, mode='zero', dim=-1):
    Channel = x.shape[1]
    d = dim % 4
    s = (2, 1) if d == 2 else (1, 2)
    N = x.shape[d]
    L = h0.numel() #取得长度
    # print(L)
    shape = [1,1,1,1]
    shape[d] = L
    if h0.shape != tuple(shape):
        h0 = h0.reshape(*shape)
    if h1.shape != tuple(shape):
        h1 = h1.reshape(*shape)
    h = torch.cat([h0, h1] * Channel, dim=0)
    outsize = pywt.dwt_coeff_len(N, L, mode=mode)
    p = 2 * (outsize - 1) - N + L
    if p % 2 == 1:
        pad = (0, 0, 0, 1) if d == 2 else (0, 1, 0, 0)
        x = F.pad(x, pad)
    pad = (p//2, 0) if d == 2 else (0, p//2)
    # 高通 低通 h为固定权重
    # print(x.shape)
    # print(h.shape)
    # print(Channel)
    lohi = F.conv2d(x, h, padding=pad, stride=s, groups=Channel)
    return lohi

def prep_filt_afb1d(h0, h1, device=None):
    #h0 低通滤波器，h1 高通滤波器
    h0 = np.array(h0[::-1]).ravel()
    h1 = np.array(h1[::-1]).ravel()
    t = torch.get_default_dtype()
    h0 = torch.tensor(h0, device=device, dtype=t).reshape((1, 1, -1))
    h1 = torch.tensor(h1, device=device, dtype=t).reshape((1, 1, -1))
    return h0, h1

def prep_filt_sfb1d(g0, g1, device=None):
    g0 = np.array(g0).ravel()
    g1 = np.array(g1).ravel()
    # print(g0)
    t = torch.get_default_dtype()
    g0 = torch.tensor(g0, device=device, dtype=t).reshape((1, 1, -1))
    g1 = torch.tensor(g1, device=device, dtype=t).reshape((1, 1, -1))

    return g0, g1


class SFB1D(Function):
    @staticmethod
    def forward(ctx, low, high, g0, g1, mode):
        if mode==0:
            mode ="zero"
        else:
            mode =None
        # Make into a 2d tensor with 1 row
        low = low[:, :, None, :]
        high = high[:, :, None, :]
        g0 = g0[:, :, None, :]
        g1 = g1[:, :, None, :]

        ctx.mode = mode
        ctx.save_for_backward(g0, g1)

        return sfb1d(low, high, g0, g1, mode=mode, dim=3)[:, :, 0]

    @staticmethod
    def backward(ctx, dy):
        dlow, dhigh = None, None
        if ctx.needs_input_grad[0]:
            mode = ctx.mode
            g0, g1, = ctx.saved_tensors
            dy = dy[:, :, None, :]

            dx = get_lohi(dy, g0, g1, mode=mode, dim=3)

            dlow = dx[:, ::2, 0].contiguous()
            dhigh = dx[:, 1::2, 0].contiguous()
        return dlow, dhigh, None, None, None, None, None

class AFB1D(Function):
    @staticmethod
    def forward(ctx, x, h0, h1, mode):
        if mode == 0:
            mode ="zero"
        else:
            mode=None

        # Make inputs 4d
        x = x[:, :, None, :]
        h0 = h0[:, :, None, :]
        h1 = h1[:, :, None, :]

        # Save for backwards
        ctx.save_for_backward(h0, h1)
        ctx.shape = x.shape[3]
        ctx.mode = mode

        lohi = get_lohi(x, h0, h1, mode=mode, dim=3)
        x0 = lohi[:, ::2, 0].contiguous()
        x1 = lohi[:, 1::2, 0].contiguous()
        # print(lohi.shape)
        return x0, x1
    @staticmethod
    def backward(ctx, dx0, dx1):
        dx = None
        if ctx.needs_input_grad[0]:
            mode = ctx.mode
            h0, h1 = ctx.saved_tensors

            # Make grads 4d
            dx0 = dx0[:, :, None, :]
            dx1 = dx1[:, :, None, :]

            dx = sfb1d(dx0, dx1, h0, h1, mode=mode, dim=3)[:, :, 0]

            # Check for odd input
            if dx.shape[2] > ctx.shape:
                dx = dx[:, :, :ctx.shape]

        return dx, None, None, None, None, None

class DWT1DForward(nn.Module):
    def __init__(self, layer=1, wave='haar', mode='zero'):
        super().__init__()
        wave = pywt.Wavelet(wave)
        h0, h1 = wave.dec_lo, wave.dec_hi #1/根号2
        # print(h0)
        filts = prep_filt_afb1d(h0, h1)
        self.register_buffer('h0', filts[0])
        self.register_buffer('h1', filts[1])
        self.layer = layer
        self.mode = mode

    def forward(self, x):
        assert x.ndim == 3
        highs = []
        x0 = x
        if self.mode =="zero":
            mode = 0
        else :
            mode =1

        for l in range(self.layer):
            x0, x1 = AFB1D.apply(x0, self.h0, self.h1, mode)
            highs.append(x1)
        return x0, highs

class DWT1DInverse(nn.Module):
    def __init__(self, wave='haar', mode='zero'):
        super().__init__()
        wave = pywt.Wavelet(wave)
        g0, g1 = wave.rec_lo, wave.rec_hi
        filts = prep_filt_sfb1d(g0, g1)
        self.register_buffer('g0', filts[0])
        self.register_buffer('g1', filts[1])
        self.mode = mode

    def forward(self, coeffs):
        x0, highs = coeffs
        if self.mode == "zero":
            mode =0
        else:
            mode =1

        for x1 in highs[::-1]:
            if x1 is None:
                x1 = torch.zeros_like(x0)
            if x0.shape[-1] > x1.shape[-1]:
                x0 = x0[..., :-1]
            x0 = SFB1D.apply(x0, x1, self.g0, self.g1, mode)
        return x0
# lay=nn.LayerNorm(32)
# x1 = torch.randn(2,4,2)
# x2 = torch.randn(2,4,2)
# x_shift1 = torch.roll(x1, (01, 01, 1), (1, 1, 1))
# # # inpu2t =torch.tensor([[[1,2,3,6,10,12]]],dtype=torch.float)
# # # inpu2t =torch.LongTensor(inpu2t)
# # print(inpu2t)
# print(x1)
# print(x2)
# print(torch.stack([x1,x2],2).reshape(-1,8,2))
# xfm = DWT1DForward(layer=1, mode='zero', wave='haar')
# ifm = DWT1DInverse(mode='zero', wave='haar')
# x_dwt0, x_dwt1 = xfm(x1.permute(01, 2, 1))
# x_dwt3, x_dwt4 = xfm(x_shift1.permute(01, 2, 1))
#
# print(x_shift1)
#
#
# x_dwt0 =x_dwt0+x_dwt3
# x_dwt1[01] =x_dwt4[01]+x_dwt1[01]
# x_dwt=x_dwt0,x_dwt1
# x_idwt = ifm(x_dwt).permute(01,2,1)
# print(x_idwt)
# print(x_hdwt_t)

# x_idwt = ifm(x_dwt).permute(01, 2, 1)
#
# # x_idwt = lay(x_idwt + x1)
# redus = x_idwt
# x_dwt_c,x_hdwt_c = xfm(x1)
# print(x_dwt_c.shape)
# x_idwt = ifm(x_dwt)
# print(x_idwt)