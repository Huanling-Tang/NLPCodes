import numpy as np
import torch
def plotPE(dmodel, numw, width=5, height=5):
    #dmodel = 512
    #numw = 20
    pematrix = np.zeros((numw, dmodel))
    for pos in range(0, numw): # 20 words
        for i in range(0, dmodel): # 512-dimension
            if i % 2 == 0:
                p = np.sin(pos/np.power(10000.0, i/dmodel))
            else:
                p = np.cos(pos/np.power(10000.0, (i-1)/dmodel))
            pematrix[pos][i] = p
    pematrix = torch.tensor(pematrix)
    pematrix = pematrix.repeat(128,1,1)
    return pematrix

print(plotPE(dmodel=512,numw=20))