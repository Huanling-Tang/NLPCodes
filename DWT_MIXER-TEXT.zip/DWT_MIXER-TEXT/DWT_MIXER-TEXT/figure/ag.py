import matplotlib.pyplot as plt

# 模型名称
model_names = ['Char-CNN', 'VDCNN', 'SVDCNN', 'XLNet', 'pNLP-Mixer-XL','DWT-Mixer-S(ours)','DWT-Mixer-L(ours)']
# 参数量数据
parameter_counts = [12.71, 17.19, 1.58, 240, 5.0,0.157,0.594]
# 准确率数据
accuracies = [92.36, 91.27, 90.6, 95.55, 91.03,91.63,92.07]
# 设置每个模型的颜色
colors = ['#1E90FF', '#9900CC', '#FF6666', '#E67C1F', '#00BFFF','#20B2AA','#FF0000',]
markers=['o','o','o','o','o','*','*']
# 设置参数量的比例因子
scale_factor = 25

# 计算散点的大小值
sizes = [param * scale_factor for param in parameter_counts]
print(sizes)
plt.figure(figsize=(18,10), dpi=300,constrained_layout=True)
plt.figure(1)
ax1 = plt.subplot(231)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax1.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax1.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax1.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax1.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)
ax1.annotate('0.594M (ours)', (parameter_counts[-1]+4.6, accuracies[-1]-0.1),weight="bold", color="black",)
ax1.annotate('12.71M', (parameter_counts[0]+6, accuracies[0]-0.08),weight="bold", color="black",)
ax1.annotate('240M', (parameter_counts[3]- 12, accuracies[3]-0.5),weight="bold", color="black",)
# ax1.annotate('0.157M (ours)', (parameter_counts[-2]+5.6, accuracies[-2]-0.08),weight="bold", color="black",)
# ax1.annotate('1.58M', (parameter_counts[2]+6, accuracies[2]-0.08),weight="bold", color="black",)
# ax1.annotate('17.19M', (parameter_counts[1]+6, accuracies[1]-0.08),weight="bold", color="black",)
# ax1.annotate('5.0M', (parameter_counts[4]+6, accuracies[4]-0.08),weight="bold", color="black",)

# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(a) The accuracy and parameters on AG News', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax1.transAxes,weight="bold",fontsize=14)
plt.title('AG News',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])



# 模型名称
model_names = ['Char-CNN', 'VDCNN', 'XLNet', 'Bert Large','pNLP-Mixer-XL','DWT-Mixer-S(ours)','DWT-Mixer-L(ours)']
# 参数量数据
parameter_counts = [12.71, 17.19, 240, 340,5.0,0.157,0.594]
# 准确率数据
accuracies = [98.58, 98.71, 99.40,99.36, 98.40,98.30,98.50]
# 设置每个模型的颜色
colors = ['#1E90FF', '#9900CC', '#E67C1F','#CC66FF',  '#00BFFF','#20B2AA','#FF0000']
markers=['o','o','o','o','o','*','*']
# 设置参数量的比例因子
scale_factor = 25

# 计算散点的大小值
sizes = [param * scale_factor for param in parameter_counts]
print(sizes)
ax2 = plt.subplot(232)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)
ax2.annotate('0.594M (ours)', (parameter_counts[-1]+9, accuracies[-1]-0.02),weight="bold", color="black",)
# ax2.annotate('12.71M', (parameter_counts[0]+9, accuracies[0]-0.02),weight="bold", color="black",)
ax2.annotate('240M', (parameter_counts[2]- 15, accuracies[2]-0.1),weight="bold", color="black",)
# ax2.annotate('0.157M (ours)', (parameter_counts[-2]+7.6, accuracies[-2]-0.02),weight="bold", color="black",)
ax2.annotate('340M', (parameter_counts[3]-15, accuracies[3]-0.1),weight="bold", color="black",)
ax2.annotate('17.19M', (parameter_counts[1]+9, accuracies[1]-0.02),weight="bold", color="black",)
ax2.annotate('5.0M', (parameter_counts[4]+9, accuracies[4]-0.02),weight="bold", color="black",)

# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(b) The accuracy and parameters on DBpedia14', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax2.transAxes,weight="bold",fontsize=14)
plt.title('DBpedia14',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])



# 模型名称
model_names = ['RoBERTa', 'XLNet', 'Bert Large','LongFormer','pNLP-Mixer-XL','DWT-Mixer-S(ours)','DWT-Mixer-L(ours)']
# 参数量数据
parameter_counts = [125, 240, 340,149,6.3,0.157,0.594]
# 准确率数据
accuracies = [95.30, 96.80, 95.49,95.70, 82.90,88.11,88.70]
# 设置每个模型的颜色
colors = ['#2E8B57', '#E67C1F', '#CC66FF','#CD853F',  '#00BFFF','#20B2AA','#FF0000']
markers=['o','o','o','o','o','*','*']
ax2 = plt.subplot(233)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)
ax2.annotate('0.594M (ours)', (parameter_counts[-1]+7.6, accuracies[-1]-0.2),weight="bold", color="black",)
ax2.annotate('125M', (parameter_counts[0]-15, accuracies[0]-1.2),weight="bold", color="black",)
ax2.annotate('340M', (parameter_counts[2]-15, accuracies[2]-1.2),weight="bold", color="black",)
# ax2.annotate('0.157M (ours)', (parameter_counts[-2]+7.6, accuracies[-2]-0.2),weight="bold", color="black",)
ax2.annotate('149M', (parameter_counts[3]+15, accuracies[3]-0.2),weight="bold", color="black",)
ax2.annotate('240M', (parameter_counts[1]+15, accuracies[1]-0.2),weight="bold", color="black",)
ax2.annotate('6.3M', (parameter_counts[-3]+7.6, accuracies[-3]-0.2),weight="bold", color="black",)

# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(c) The accuracy and parameters on IMDB', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax2.transAxes,weight="bold",fontsize=14)
plt.title('IMDB',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])




# 模型名称
model_names = ['Char-CNN', 'VDCNN', 'SVDCNN', 'XLNet','Bert Large', 'pNLP-Mixer-XL','DWT-Mixer-S(ours)','DWT-Mixer-L(ours)']
# 参数量数据
parameter_counts = [12.71, 17.19, 1.58, 240, 340,6.3,0.157,0.594]
# 准确率数据
accuracies = [95.64, 95.72, 95.30, 98.63, 98.11,94.62,95.67,96.02]
# 设置每个模型的颜色
colors = ['#1E90FF', '#9900CC', '#FF6666', '#E67C1F','#CC66FF', '#00BFFF','#20B2AA','#FF0000',]
markers=['o','o','o','o','o','o','*','*']
ax2 = plt.subplot(234)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)

# ax2.annotate('12.71M', (parameter_counts[0]-15, accuracies[0]-0.2),weight="bold", color="black",)
# ax2.annotate('17.19M', (parameter_counts[1]+8.6, accuracies[1]-0.2),weight="bold", color="black",)
# ax2.annotate('1.58M', (parameter_counts[2]-15, accuracies[2]-0.2),weight="bold", color="black",)
ax2.annotate('240M', (parameter_counts[3]-16, accuracies[3]-0.36),weight="bold", color="black",)
ax2.annotate('340M', (parameter_counts[4]-16, accuracies[4]-0.36),weight="bold", color="black",)
ax2.annotate('6.3M', (parameter_counts[-3]+7.6, accuracies[-3]-0.05),weight="bold", color="black",)
# ax2.annotate('0.157M (ours)', (parameter_counts[-2]+7.6, accuracies[-2]-0.08),weight="bold", color="black",)
ax2.annotate('0.594M (ours)', (parameter_counts[-1]+7.6, accuracies[-1]-0.08),weight="bold", color="black",)
# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(d) The accuracy and parameters on Yelp-2', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax2.transAxes,weight="bold",fontsize=14)
plt.title('Yelp-2',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])


# 模型名称
model_names = ['RoBERTa', 'XLNet', 'Bert Large','TinyBert','MobileBert','FNet','gMLP$_{Large}$','HyperMixer','pNLP-Mixer-XL','DWT-Mixer-S(ours)','DWT-Mixer-L(ours)']
# 参数量数据
parameter_counts = [125, 240, 340,14.5,25.3,83,365,11,4.9,0.157,0.594]
# 准确率数据
accuracies = [96.70, 97.00, 94.9,92.6,92.8,94.0,94.8,80.9, 80.94,83.32,86.26]
# 设置每个模型的颜色
colors = ['#2E8B57', '#E67C1F', '#CC66FF','#FF66CC','#4682B4', '#FFA500','#DB7093','#4169E1','#00BFFF','#20B2AA','#FF0000']
markers=['o','o','o','o','o','o','o','o','o','*','*']
ax2 = plt.subplot(235)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)

ax2.annotate('125M', (parameter_counts[0]-15, accuracies[0]-1.5),weight="bold", color="black",)
ax2.annotate('240M', (parameter_counts[1]-15, accuracies[1]-1.5),weight="bold", color="black",)
# ax2.annotate('1.58M', (parameter_counts[2]-15, accuracies[2]-0.2),weight="bold", color="black",)
# ax2.annotate('240M', (parameter_counts[3]-12, accuracies[3]-0.3),weight="bold", color="black",)
# ax2.annotate('340M', (parameter_counts[4]-12, accuracies[4]-0.3),weight="bold", color="black",)
# ax2.annotate('6.3M', (parameter_counts[-3]+7.6, accuracies[-3]-0.08),weight="bold", color="black",)
# ax2.annotate('0.157M (ours)', (parameter_counts[-2]+7.6, accuracies[-2]-0.14),weight="bold", color="black",)
ax2.annotate('0.594M (ours)', (parameter_counts[-1]+7.6, accuracies[-1]-0.14),weight="bold", color="black",)
# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(e) The accuracy and parameters on SST-2', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax2.transAxes,weight="bold",fontsize=14)
plt.title('SST-2',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])

# 模型名称
model_names = ['RoBERTa', 'XLNet', 'Bert Large','TinyBert','MobileBert','FNet','pNLP-Mixer-XL','DWT-Mixer-S(ours)']
# 参数量数据
parameter_counts = [125, 240, 340,14.5,25.3,83,4.9,0.157]
# 准确率数据
accuracies = [67.80, 70.20, 60.5,43.3,50.5,78.0, 69.33,71.55]
# 设置每个模型的颜色
colors = ['#2E8B57', '#E67C1F', '#CC66FF','#FF66CC','#4682B4',  '#FFA500','#00BFFF','#20B2AA']
markers=['o','o','o','o','o','o','o','*','*']
ax2 = plt.subplot(236)
# 绘制散点图
for i in range(len(model_names)):
    if parameter_counts[i]>100 :
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*7, marker=markers[i],color=colors[i], label=model_names[i])
    elif parameter_counts[i] > 10 and parameter_counts[i]<=100:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100 * 3, marker=markers[i], color=colors[i],
                    label=model_names[i])
    elif parameter_counts[i] > 1 and parameter_counts[i] <=10:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100*2, marker=markers[i], color=colors[i],
                    label=model_names[i])
    else:
        ax2.scatter(parameter_counts[i], accuracies[i], s=100, marker=markers[i],color=colors[i], label=model_names[i])
# 添加数据标签
# for i, name in enumerate(model_names):
# plt.annotate(model_names[-1], (parameter_counts[-1], accuracies[-1]),weight="bold", color="black",)

ax2.annotate('125M', (parameter_counts[0]-15, accuracies[0]-3),weight="bold", color="black",)
ax2.annotate('240M', (parameter_counts[1]-15, accuracies[1]-3),weight="bold", color="black",)
# ax2.annotate('1.58M', (parameter_counts[2]-15, accuracies[2]-0.2),weight="bold", color="black",)
# ax2.annotate('240M', (parameter_counts[3]-12, accuracies[3]-0.3),weight="bold", color="black",)
# ax2.annotate('340M', (parameter_counts[4]-12, accuracies[4]-0.3),weight="bold", color="black",)
ax2.annotate('83M', (parameter_counts[-3]+9, accuracies[-3]-0.6),weight="bold", color="black",)
ax2.annotate('0.157M (ours)', (parameter_counts[-1]+7.6, accuracies[-1]-0.6),weight="bold", color="black",)
# ax2.annotate('0.594M (ours)', (parameter_counts[-1]+7.6, accuracies[-1]-0.14),weight="bold", color="black",)
# 设置轴标签和标题
plt.xlabel('Parameter (M)')
plt.ylabel('Accuracy (%)')
plt.text(0.5, -0.15, '(f) The accuracy and parameters on CoLA', \
      horizontalalignment='center', verticalalignment='center', \
      transform=ax2.transAxes,weight="bold",fontsize=14)
plt.title('CoLA',weight="bold")
plt.grid(linestyle='--',zorder=0)

# 添加图例
lgnd = plt.legend(loc="lower right", scatterpoints=1, fontsize=10)
for handle in lgnd.legendHandles:
    handle.set_sizes([100])

# plt.rc('font',family='Times New Roman')
# 显示图表
plt.savefig("./models.svg",dpi=300,)
plt.show()

# fig.show()