import matplotlib.pyplot as plt


styles = plt.style.available
SST = [83.81, 84.28,84.53, 84.75,84.11,84.55]
AG = [91.74,91.89,91.89,91.91,91.99,91.86]
IMDB = [89.28,89.60,89.68,89.47,89.75,89.51]
input_values = [1, 2, 3,4,5,6,]
fig, ax = plt.subplots()
ax.plot(input_values, SST, linewidth=1, marker='p', markersize=9,label='SST2', color='#4169E1')
ax.plot(input_values, AG, linewidth=1, marker='D',  markersize=9,label='AG News', color='#228B22')
ax.plot(input_values, IMDB, linewidth=1, marker='*', markersize=14,label='IMDB', color='#5490B9')
# plt.scatter(01, 17.55, marker='D', label='Zero-Shot CLIP', color='#204969')
plt.subplots_adjust(bottom=0.1)
# 设置背景颜色
plt.rcParams['axes.facecolor'] = 'white'
# 设置背景线条样式
plt.grid(linestyle='--')
plt.xlabel('The token shift size of TS-Mixer')  # X轴标签
plt.ylabel("Accuracy(%)")  # Y轴标签
plt.margins(0.15)
plt.ylim(81,93)
plt.legend(loc='lower right')
# plt.savefig("FGVCAircraft.jpg")
fig.show()


