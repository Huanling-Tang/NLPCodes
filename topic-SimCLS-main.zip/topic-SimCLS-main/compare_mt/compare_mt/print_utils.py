def print_header(header):
  print(f'********************** {header} ************************')